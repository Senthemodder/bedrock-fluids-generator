export const FluidRegistry = {
  "lumstudio:sulphuric_acid": {
    "damage": 0,
    "fog": "0fed43",
    "buoyancy": 0.03,
    "boat": true,
    "burnTime": 5,
    "effect": "poison"
  }
};