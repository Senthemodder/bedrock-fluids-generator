import "./fluids.js";
